#include<NXP/iolpc2124.h>
#include"system.h"
#include"timer.h"
#include"delay.h"

void Gpio_init();
void blink_led();
void main()
{
 clock_init();
 Gpio_init();
  while (1) {
  blink_led();
 }
 }
void Gpio_init(){
 PINSEL0=0x00003f00;
 IO0DIR=0x00003f00;
 }
void blink_led()
{
  for(int i=8;i<=13;i++){
    IO0SET=(1<<i);
    delay_ms(100);
    IO0CLR=(1<<i);
    for(int j=8;j<=13;j++)
    {
    if (j != i) {
     IO0CLR=(1<<j); 
  }
  }
  }
  }
  
 
