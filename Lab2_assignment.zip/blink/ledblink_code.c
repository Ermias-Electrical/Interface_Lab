#include<NXP/iolpc2124.h>
#include"system.h"
void Gpio_init();
void blink();
void delay(int count);


void main()
{
 Gpio_init();
  
 while (1) {
        blink();
        delay(100);
    }
 
  }
 
void Gpio_init(){
 PINSEL0_bit.P0_0=0;
 IO0DIR_bit.P0_0=1;
 //IO0SET_bit.P0_0=1;
 
}
 void delay(int count)
 {
 for(int i=0;i<count;i++)
 {
 }
 }
 void blink()
 {
   if(IO0PIN_bit.P0_0==1){
     
     IO0CLR_bit.P0_0=1;
   
   }
   else{
   IO0SET_bit.P0_0=1;
   }
 }



