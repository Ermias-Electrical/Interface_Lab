/*--------------------------------------------------------------
 File:      main.c
 Purpose:   Header file for system driver
 Compiler:  IAR EW 5.5
 MCU:       Philips LPC2148 (ARM7TDMI)
----------------------------------------------------------------*/

//function prototype
void clock_init(void);   

