#include "NXP/iolpc2124.h"
#include "timer.h"


//starts the timer 
void start_timer0()
{
T0CTCR=0; //timer mode (the timer can be configured as counter)
T0TCR_bit.CE=1;//enable timer, timer starts counting
}

//stops the timer
void stop_timer0()
{
 T0TCR_bit.CE=0;//disable timer, timer stops counting
}

//clears the timer/counter register
void clear_timer0()
{
T0TC=0;
}

//returns the value of timer/counter register
unsigned int read_timer0()
{
return T0TC;//return value of T0TC
}