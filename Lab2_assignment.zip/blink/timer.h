
void start_timer0();
void stop_timer0();
void clear_timer0();
unsigned int read_timer0();