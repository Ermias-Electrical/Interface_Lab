#include<NXP/iolpc2124.h>
#include"system.h"
#include"timer.h"
#include"delay.h"

void Gpio_init();
void blink();
void main()
{
 clock_init();
 Gpio_init();
  while (1) {
  blink();
  delay_ms(100);
 }
 }
void Gpio_init(){
 PINSEL0_bit.P0_0=0;
 IO0DIR_bit.P0_0=1;
 
}
void blink()
{
 if(IO0PIN_bit.P0_0==1){
 IO0CLR_bit.P0_0=1;
 }
else{
IO0SET_bit.P0_0=1;
   }
 }