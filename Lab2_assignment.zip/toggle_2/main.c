#include<NXP/iolpc2124.h>
#include"system.h"
#include"timer.h"
#include"delay.h"
void Gpio_init();
void toggle();
void main()
{
 clock_init();
 Gpio_init();
 while (1) {
    if(IO0PIN_bit.P0_14==0){
    toggle();
    }
   delay_ms(100);
 
 }
 }
void Gpio_init(){
 PINSEL0_bit.P0_8=0;
 PINSEL0_bit.P0_14=0;
 IO0DIR_bit.P0_8=1;
 IO0DIR_bit.P0_14=0;
}
void toggle()
{
 if(IO0PIN_bit.P0_8){
 IO0CLR_bit.P0_8=1;
 }
else{
IO0SET_bit.P0_8=1;
   }
 }